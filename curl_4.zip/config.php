﻿<?php
/** Share by HOCTRICK.NET
 **/


$dm = 'http://hoctrick.net'; // ko có kí tự / ở cuối nhé


$uid = '123456'; // id facebook của bạn